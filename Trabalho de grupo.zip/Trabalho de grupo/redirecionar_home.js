function voltaHomePage(){
    window.open('homepage.html');
}