sessionStorage.descricao = document.getElementById('descricao').innerText;
sessionStorage.valor = document.getElementById('valor').innerText;

function resumoCompra(){
    window.open('carrinho.html');
}