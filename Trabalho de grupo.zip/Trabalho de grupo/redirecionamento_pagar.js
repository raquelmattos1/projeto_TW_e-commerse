function pagar(){
    window.open('pago.html');
}